//////   communication   ////////////

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log(sender.tab ?
                "from a content script:" + sender.tab.url :
                "from the extension");  
	chrome.tabs.query({url: request.destination}, function(tabs) {
		destination_id = tabs[0].id;	
		console.log('destination_id', destination_id);
		chrome.tabs.sendMessage(destination_id, request, function(response) {});
	});      

});	


// ////////////////////////////////////////

chrome.runtime.onInstalled.addListener(function() {
  
  chrome.declarativeContent.onPageChanged.removeRules(undefined, function() {
    chrome.declarativeContent.onPageChanged.addRules([{
      conditions: [new chrome.declarativeContent.PageStateMatcher({
        // pageUrl: {hostEquals: 'developer.chrome.com'},
      })],
      actions: [new chrome.declarativeContent.ShowPageAction()]
    }]);
  });
});



